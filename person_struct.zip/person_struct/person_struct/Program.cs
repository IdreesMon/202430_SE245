﻿namespace PersonStruct
{
    class Helper
    {
        static public string AskStringQuestion(string question)
        {
            Console.Write($"{question}: ");
            return Helper.GetString();
        }

        static public int AskIntQuestion(string question)
        {
            Console.Write($"{question}: ");
            return Helper.GetInt();
        }

        static public string GetString()
        {
            string? output = null;
            do
            {
                string? userInput = Console.ReadLine();

                if (userInput == null)
                {
                    Console.Write("Bad Input, try again: ");
                }
                else
                {
                    output = userInput;
                }
            } while (output == null);

            return output;
        }

        static public int GetInt()
        {
            int output;
            bool successful;

            do
            {
                string userInput = Helper.GetString();

                successful = int.TryParse(userInput, out output);
                if (!successful)
                {
                    Console.Write("Bad Input, try again: ");
                }
                else
                {

                }
            } while (!successful);

            return output;
        }
    }
    class Person
    {
        private string _firstName;
        private string _middleName;
        private string _lastName;
        private string _streetOne;
        private string _streetTwo;
        private string _city;
        private string _state;
        private int _zip;
        private string _emailAddress;
        private string _phoneNumber;

        public Person(
            string firstName,
            string middleName,
            string lastName,
            string streetOne,
            string streetTwo,
            string city,
            string state,
            int zip,
            string emailAddress,
            string phoneNumber
        )
        {
            _firstName = firstName + "poopy";
            _middleName = middleName;
            _lastName = lastName;
            _streetOne = streetOne;
            _streetTwo = streetTwo;
            _city = city;
            _state = state;
            _zip = zip;
            _emailAddress = emailAddress;
            _phoneNumber = phoneNumber;
        }

        public string FirstName
        {
            get => _firstName;
            set
            {
                Console.WriteLine("updating name!");
                _firstName = value;
            }
        }

        public string MiddleName
        {
            get => _middleName;
            set
            {
                _middleName = value;
            }
        }

        public string LastName
        {
            get => _lastName;
            set
            {
                _lastName = value;
            }
        }

        public string StreetOne
        {
            get => _streetOne;
            set
            {
                _streetOne = value;
            }
        }

        public string StreetTwo
        {
            get => _streetTwo;
            set
            {
                _streetTwo = value;
            }
        }

        public string City
        {
            get => _city;
            set
            {
                _city = value;
            }
        }

        public string State
        {
            get => _state;
            set
            {
                _state = value;
            }
        }

        public int ZIP
        {
            get => _zip;
            set
            {
                _zip = value;
            }
        }

        public string EmailAddress
        {
            get => _emailAddress;
            set
            {
                _emailAddress = value;
            }
        }

        public string PhoneNumber
        {
            get => _phoneNumber;
            set
            {
                _phoneNumber = value;
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Person slater = new(
                Helper.AskStringQuestion("First Name"),
                Helper.AskStringQuestion("Middle Name"),
                Helper.AskStringQuestion("Last Name"),
                Helper.AskStringQuestion("Street One"),
                Helper.AskStringQuestion("Street Two"),
                Helper.AskStringQuestion("City"),
                Helper.AskStringQuestion("State"),
                Helper.AskIntQuestion("ZIP code"),
                Helper.AskStringQuestion("Email"),
                Helper.AskStringQuestion("Phone Number")
            ); ; ;

            Console.WriteLine(slater.FirstName);
            slater.FirstName = "xxxx";
            Console.WriteLine(slater.FirstName);
        }
    }
}